import { API_VERSION } from "./sf-session.js";

/**
 * @param {string} apiBase
 * @param {string} sessionId
 * @param {string} soql
 */
export async function toolingQuery(apiBase, sessionId, soql) {
  const q = encodeURIComponent(soql);
  const url = `${apiBase}/services/data/${API_VERSION}/tooling/query?q=${q}`;
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${sessionId}`,
      Accept: "application/json",
    },
  });
  const text = await res.text();
  let body;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = { raw: text };
  }
  if (!res.ok) {
    const msg =
      body?.[0]?.message ||
      body?.message ||
      body?.error ||
      text ||
      `HTTP ${res.status}`;
    throw new Error(String(msg));
  }
  return body;
}

async function toolingRequest(apiBase, sessionId, path, options = {}) {
  const url = `${apiBase}${path}`;
  const headers = {
    Authorization: `Bearer ${sessionId}`,
    Accept: "application/json",
    ...(options.body ? { "Content-Type": "application/json" } : {}),
    ...(options.headers || {}),
  };
  const res = await fetch(url, { ...options, headers });
  const text = await res.text();
  let body;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = { raw: text };
  }
  if (!res.ok) {
    const msg =
      body?.[0]?.message ||
      body?.message ||
      body?.error ||
      text ||
      `HTTP ${res.status}`;
    throw new Error(String(msg));
  }
  return body;
}

/**
 * @param {string} apiBase
 * @param {string} sessionId
 * @param {number} limit
 */
export async function listApexLogs(apiBase, sessionId, limit, logUserId = null) {
  const safeLimit = Math.min(Math.max(Number(limit) || 50, 1), 200);
  const where = logUserId
    ? `WHERE LogUserId = '${String(logUserId).replace(/'/g, "\\'")}'`
    : "";
  const soql = [
    "SELECT Id, Application, DurationMilliseconds, Location, LogLength,",
    "LogUserId, LogUser.Name, Operation, Request, Status, StartTime",
    "FROM ApexLog",
    where,
    "ORDER BY StartTime DESC",
    `LIMIT ${safeLimit}`,
  ]
    .filter(Boolean)
    .join(" ");
  return toolingQuery(apiBase, sessionId, soql);
}

export async function listActiveUsers(apiBase, sessionId, limit = 500) {
  const safeLimit = Math.min(Math.max(Number(limit) || 500, 1), 2000);
  const soql = [
    "SELECT Id, Name, Username",
    "FROM User",
    "ORDER BY Name ASC",
    `LIMIT ${safeLimit}`,
  ].join(" ");
  return toolingQuery(apiBase, sessionId, soql);
}

function escapeSoqlLikeLiteral(value) {
  return String(value)
    .replace(/\\/g, "\\\\")
    .replace(/'/g, "\\'")
    .replace(/[%_]/g, "\\$&");
}

export async function searchUsers(apiBase, sessionId, query, limit = 100) {
  const trimmed = String(query || "").trim();
  if (trimmed.length < 3) return { records: [] };
  const safeLimit = Math.min(Math.max(Number(limit) || 100, 1), 200);
  const contains = `%${escapeSoqlLikeLiteral(trimmed)}%`;
  const soql = [
    "SELECT Id, Name, Username",
    "FROM User",
    `WHERE (Name LIKE '${contains}' OR Username LIKE '${contains}')`,
    "ORDER BY Name ASC",
    `LIMIT ${safeLimit}`,
  ].join(" ");
  return toolingQuery(apiBase, sessionId, soql);
}

function toSfDateTimeIso(date) {
  return new Date(date).toISOString().replace(/\.\d{3}Z$/, "Z");
}

const DEFAULT_DEBUG_LEVELS = {
  ApexCode: "DEBUG",
  ApexProfiling: "INFO",
  Callout: "INFO",
  Database: "INFO",
  System: "DEBUG",
  Validation: "INFO",
  Visualforce: "INFO",
  Workflow: "INFO",
};

const ALLOWED_LEVELS = new Set([
  "NONE",
  "ERROR",
  "WARN",
  "INFO",
  "DEBUG",
  "FINE",
  "FINER",
  "FINEST",
]);

function normalizeDebugLevels(debugLevels) {
  const normalized = {};
  for (const [field, fallback] of Object.entries(DEFAULT_DEBUG_LEVELS)) {
    const raw = String(debugLevels?.[field] || fallback).toUpperCase();
    normalized[field] = ALLOWED_LEVELS.has(raw) ? raw : fallback;
  }
  return normalized;
}

/**
 * Salesforce rejects a DeveloperName that contains consecutive underscores,
 * ends with an underscore, or exceeds 40 characters.
 * @param {Record<string, string>} levels
 */
function buildDebugLevelDeveloperName(levels) {
  const prefix = "SFDbg";
  const suffix = Date.now().toString(36).slice(-6).toUpperCase();
  const maxCompact = 40 - prefix.length - suffix.length - 2;
  const compact = [
    levels.ApexCode,
    levels.ApexProfiling,
    levels.Callout,
    levels.Database,
    levels.System,
    levels.Validation,
    levels.Visualforce,
    levels.Workflow,
  ]
    .join("_")
    .replace(/[^A-Za-z0-9_]/g, "")
    .slice(0, maxCompact)
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
  return [prefix, compact, suffix].filter(Boolean).join("_");
}

export async function getOrCreateDebugLevel(apiBase, sessionId, debugLevels = {}) {
  const levels = normalizeDebugLevels(debugLevels);
  const soql = [
    "SELECT Id, DeveloperName, MasterLabel",
    "FROM DebugLevel",
    `WHERE ApexCode = '${levels.ApexCode}'`,
    `AND ApexProfiling = '${levels.ApexProfiling}'`,
    `AND Callout = '${levels.Callout}'`,
    `AND Database = '${levels.Database}'`,
    `AND System = '${levels.System}'`,
    `AND Validation = '${levels.Validation}'`,
    `AND Visualforce = '${levels.Visualforce}'`,
    `AND Workflow = '${levels.Workflow}'`,
    "LIMIT 1",
  ].join(" ");
  const existing = await toolingQuery(apiBase, sessionId, soql);
  if (existing?.records?.[0]?.Id) {
    return existing.records[0].Id;
  }

  const developerName = buildDebugLevelDeveloperName(levels);
  const masterLabel = `SF Debugger ${developerName.split("_").pop()}`.slice(0, 80);

  const created = await toolingRequest(
    apiBase,
    sessionId,
    `/services/data/${API_VERSION}/tooling/sobjects/DebugLevel`,
    {
      method: "POST",
      body: JSON.stringify({
        DeveloperName: developerName,
        MasterLabel: masterLabel,
        ...levels,
      }),
    }
  );
  return created?.id || null;
}

export async function getTraceFlagStatus(apiBase, sessionId, userId) {
  const escapedUserId = String(userId).replace(/'/g, "\\'");
  const nowIso = toSfDateTimeIso(new Date());

  const activeSoql = [
    "SELECT Id, TracedEntityId, DebugLevelId, StartDate, ExpirationDate, LogType",
    "FROM TraceFlag",
    `WHERE TracedEntityId = '${escapedUserId}'`,
    "AND LogType = 'USER_DEBUG'",
    `AND ExpirationDate >= ${nowIso}`,
    "ORDER BY ExpirationDate DESC",
    "LIMIT 1",
  ].join(" ");
  const active = await toolingQuery(apiBase, sessionId, activeSoql);
  if (active?.records?.[0]) {
    return { active: true, traceFlag: active.records[0] };
  }

  const expiredSoql = [
    "SELECT Id, TracedEntityId, DebugLevelId, StartDate, ExpirationDate, LogType",
    "FROM TraceFlag",
    `WHERE TracedEntityId = '${escapedUserId}'`,
    "AND LogType = 'USER_DEBUG'",
    `AND ExpirationDate < ${nowIso}`,
    "ORDER BY ExpirationDate DESC",
    "LIMIT 1",
  ].join(" ");
  const expired = await toolingQuery(apiBase, sessionId, expiredSoql);
  return {
    active: false,
    expiredTraceFlag: expired?.records?.[0] || null,
  };
}

export async function createTraceFlag(apiBase, sessionId, userId, debugLevelId, durationMinutes) {
  const start = new Date();
  const end = new Date(start.getTime() + Number(durationMinutes) * 60 * 1000);
  return toolingRequest(
    apiBase,
    sessionId,
    `/services/data/${API_VERSION}/tooling/sobjects/TraceFlag`,
    {
      method: "POST",
      body: JSON.stringify({
        TracedEntityId: userId,
        DebugLevelId: debugLevelId,
        LogType: "USER_DEBUG",
        StartDate: toSfDateTimeIso(start),
        ExpirationDate: toSfDateTimeIso(end),
      }),
    }
  );
}

/**
 * Delete a TraceFlag by Id (Tooling API).
 * @param {string} apiBase
 * @param {string} sessionId
 * @param {string} traceFlagId
 */
export async function deleteTraceFlag(apiBase, sessionId, traceFlagId) {
  const base = String(apiBase || "").replace(/\/+$/, "");
  const id = encodeURIComponent(traceFlagId);
  const path = `/services/data/${API_VERSION}/tooling/sobjects/TraceFlag/${id}`;
  const res = await fetch(`${base}${path}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${sessionId}`,
      Accept: "application/json",
    },
  });
  if (res.status === 204 || res.ok) return;
  const text = await res.text();
  let body;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = { raw: text };
  }
  const msg =
    body?.[0]?.message || body?.message || body?.error || text || `HTTP ${res.status}`;
  throw new Error(String(msg));
}

/**
 * Remove the active USER_DEBUG trace for a user, if any.
 * @param {string} apiBase
 * @param {string} sessionId
 * @param {string} userId
 * @returns {Promise<{ removed: boolean, traceFlagId?: string }>}
 */
export async function removeActiveUserDebugTrace(apiBase, sessionId, userId) {
  const status = await getTraceFlagStatus(apiBase, sessionId, userId);
  if (!status.active || !status.traceFlag?.Id) {
    return { removed: false };
  }
  const traceFlagId = status.traceFlag.Id;
  await deleteTraceFlag(apiBase, sessionId, traceFlagId);
  return { removed: true, traceFlagId };
}

/**
 * @param {string} apiBase
 * @param {string} sessionId
 * @param {string} logId
 */
export async function getApexLogBody(apiBase, sessionId, logId) {
  const id = encodeURIComponent(logId);
  const paths = [
    `/services/data/${API_VERSION}/tooling/sobjects/ApexLog/${id}/Body/Body`,
    `/services/data/${API_VERSION}/tooling/sobjects/ApexLog/${id}/Body`,
    `/services/data/${API_VERSION}/sobjects/ApexLog/${id}/Body`,
  ];

  let lastErr = "Unknown error";
  for (const path of paths) {
    const url = `${apiBase}${path}`;
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${sessionId}`,
        Accept: "text/plain,*/*",
      },
    });
    if (res.ok) {
      return await res.text();
    }
    lastErr = (await res.text()) || `HTTP ${res.status}`;
  }
  throw new Error(lastErr);
}

/**
 * @param {string} apiBase
 * @param {string} sessionId
 * @param {string|null} logUserId - if set, only logs for that user
 * @returns {Promise<string[]>}
 */
export async function queryAllApexLogIds(apiBase, sessionId, logUserId = null) {
  const base = String(apiBase || "").replace(/\/+$/, "");
  const where = logUserId
    ? `WHERE LogUserId = '${String(logUserId).replace(/'/g, "\\'")}'`
    : "";
  const soql = `SELECT Id FROM ApexLog ${where}`.trim().replace(/\s+/g, " ");
  /** @type {string[]} */
  const ids = [];
  let url = `${base}/services/data/${API_VERSION}/tooling/query?q=${encodeURIComponent(soql)}`;

  while (url) {
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${sessionId}`,
        Accept: "application/json",
      },
    });
    const text = await res.text();
    let data;
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      throw new Error(text || "Invalid JSON from Tooling query");
    }
    if (!res.ok) {
      const msg =
        data?.[0]?.message || data?.message || data?.error || text || `HTTP ${res.status}`;
      throw new Error(String(msg));
    }
    for (const rec of data.records || []) {
      if (rec.Id) ids.push(rec.Id);
    }
    if (data.done || !data.nextRecordsUrl) {
      url = "";
    } else {
      const next = data.nextRecordsUrl;
      url = next.startsWith("http") ? next : `${base}${next}`;
    }
  }
  return ids;
}

/**
 * @param {string} apiBase
 * @param {string} sessionId
 * @param {string} logId
 */
export async function deleteApexLog(apiBase, sessionId, logId) {
  const base = String(apiBase || "").replace(/\/+$/, "");
  const id = encodeURIComponent(logId);
  const path = `/services/data/${API_VERSION}/tooling/sobjects/ApexLog/${id}`;
  const res = await fetch(`${base}${path}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${sessionId}`,
      Accept: "application/json",
    },
  });
  if (res.status === 204 || res.ok) return;
  const text = await res.text();
  let body;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = { raw: text };
  }
  const msg =
    body?.[0]?.message || body?.message || body?.error || text || `HTTP ${res.status}`;
  throw new Error(String(msg));
}

/**
 * @param {string} apiBase
 * @param {string} sessionId
 * @param {string[]} logIds
 */
export async function deleteApexLogs(apiBase, sessionId, logIds) {
  const unique = [...new Set(logIds.filter(Boolean))];
  /** @type {{ id: string, message: string }[]} */
  const errors = [];
  let deleted = 0;
  const chunkSize = 8;
  for (let i = 0; i < unique.length; i += chunkSize) {
    const chunk = unique.slice(i, i + chunkSize);
    const settled = await Promise.allSettled(
      chunk.map((id) => deleteApexLog(apiBase, sessionId, id))
    );
    settled.forEach((r, j) => {
      if (r.status === "fulfilled") deleted += 1;
      else {
        errors.push({
          id: chunk[j],
          message: r.reason?.message || String(r.reason),
        });
      }
    });
  }
  return { deleted, errors, totalAttempted: unique.length };
}
