import {
  SETTINGS_STORAGE_DEFAULTS,
  DEFAULT_DEBUG_LEVELS,
  initAllDebugLevelSelects,
  readDebugLevelsFromSelects,
  applyDebugLevelsToSelects,
  clampLogLimit,
  clampTraceMinutes,
  normalizeOpenMode,
  normalizeAiProvider,
  sanitizeAiText,
} from "../lib/extension-settings.js";

const logList = document.getElementById("logList");
const emptyState = document.getElementById("emptyState");
const errorState = document.getElementById("errorState");
const statusBadge = document.getElementById("statusBadge");
const traceStatus = document.getElementById("traceStatus");
const btnRefresh = document.getElementById("btnRefresh");
const btnSetLog = document.getElementById("btnSetLog");
const btnRemoveLog = document.getElementById("btnRemoveLog");
const SET_LOG_TITLE_DEFAULT = "Set trace flag for the selected user";
const SET_LOG_TITLE_ACTIVE =
  "Debug trace is already active for this user (see message below)";
const REMOVE_LOG_TITLE_REMOVE =
  "Remove debug trace for this user (stop capturing new logs)";
const REMOVE_LOG_TITLE_NEED_USER =
  "Select a specific log user (not All) to remove a trace";
const REMOVE_LOG_TITLE_NO_TRACE = "No active debug trace for this user";
const REMOVE_LOG_TITLE_NEED_SF_TAB = "Open a Salesforce tab first";
const refreshSelect = document.getElementById("refreshSelect");
const userSearchInput = document.getElementById("userSearchInput");
const userTypeaheadList = document.getElementById("userTypeaheadList");
const btnOpenSettings = document.getElementById("btnOpenSettings");
const settingsOverlay = document.getElementById("settingsOverlay");
const btnCloseSettings = document.getElementById("btnCloseSettings");
const settLogLimit = document.getElementById("settLogLimit");
const settRefreshSeconds = document.getElementById("settRefreshSeconds");
const openModeToggle = document.getElementById("openModeToggle");
const settOpenModeTab = document.getElementById("settOpenModeTab");
const settTraceDurationMinutes = document.getElementById("settTraceDurationMinutes");
const settSavedHint = document.getElementById("settSavedHint");
const settDbgApexCode = document.getElementById("settDbgApexCode");
const settDbgApexProfiling = document.getElementById("settDbgApexProfiling");
const settDbgCallout = document.getElementById("settDbgCallout");
const settDbgDatabase = document.getElementById("settDbgDatabase");
const settDbgSystem = document.getElementById("settDbgSystem");
const settDbgValidation = document.getElementById("settDbgValidation");
const settDbgVisualforce = document.getElementById("settDbgVisualforce");
const settDbgWorkflow = document.getElementById("settDbgWorkflow");
const settAiProvider = document.getElementById("settAiProvider");
const settAiModel = document.getElementById("settAiModel");
const settAiApiKey = document.getElementById("settAiApiKey");
const settAiEndpoint = document.getElementById("settAiEndpoint");
const settAiAgentforceOrgUrl = document.getElementById("settAiAgentforceOrgUrl");
const settAiModelField = document.getElementById("settAiModelField");
const settAiApiKeyField = document.getElementById("settAiApiKeyField");
const settAiEndpointField = document.getElementById("settAiEndpointField");
const settAiAgentforceOrgField = document.getElementById("settAiAgentforceOrgField");
const settAiProviderNote = document.getElementById("settAiProviderNote");
const extensionVersion = document.getElementById("extension-version");
const chkSelectAllLogs = document.getElementById("chkSelectAllLogs");
const btnClearSelected = document.getElementById("btnClearSelected");
const btnClearAllLogs = document.getElementById("btnClearAllLogs");

const queryParams = new URLSearchParams(window.location.search);
const isFullTabView = queryParams.get("view") === "tab";

const FILTER_ALL = "__ALL__";

let refreshTimer = null;
let lastSfTabId = null;
let allUsers = [];
let selectedUserId = FILTER_ALL;
let selectedUserLabel = "All";
let userSearchDebounceTimer = null;
let userSearchRequestSeq = 0;
const MIN_REMOTE_USER_SEARCH_LENGTH = 3;
const DEFAULT_TRACE_USER_KEY = "defaultTraceUserSelection";

if (extensionVersion) {
  extensionVersion.textContent = `v${chrome.runtime.getManifest().version}`;
}

if (isFullTabView) {
  document.body.classList.add("popup-mode--tab");
}

function logJsError(context, error) {
  const message = error?.stack || error?.message || String(error);
  console.log(`[SF Debugger][${context}] ${message}`, error);
}

window.addEventListener("error", (event) => {
  logJsError("popup error", event.error || event.message);
});

window.addEventListener("unhandledrejection", (event) => {
  logJsError("popup unhandled rejection", event.reason);
});

function getFullTabUrl() {
  return chrome.runtime.getURL("popup/popup.html?view=tab");
}

async function maybeOpenFullTabFromPreference() {
  if (isFullTabView) return true;
  try {
    const cfg = await chrome.storage.sync.get({
      openMode: SETTINGS_STORAGE_DEFAULTS.openMode,
    });
    if (normalizeOpenMode(cfg.openMode) !== "tab") return true;
    await chrome.tabs.create({ url: getFullTabUrl() });
    window.close();
    return false;
  } catch (error) {
    logJsError("maybeOpenFullTabFromPreference", error);
    return true;
  }
}

async function persistOpenMode(openMode) {
  const nextMode = normalizeOpenMode(openMode);
  await chrome.storage.sync.set({ openMode: nextMode });
  const asTab = nextMode === "tab";
  if (openModeToggle) openModeToggle.checked = asTab;
  if (settOpenModeTab) settOpenModeTab.checked = asTab;
}

async function handleOpenModeToggleChange(enabled) {
  const openMode = enabled ? "tab" : "popup";
  try {
    await persistOpenMode(openMode);
    if (enabled && !isFullTabView) {
      await chrome.tabs.create({ url: getFullTabUrl() });
      window.close();
    } else if (!enabled && isFullTabView) {
      showTraceStatus("Full tab mode disabled. Next toolbar click opens compact popup.", "ok");
    }
  } catch (error) {
    logJsError("handleOpenModeToggleChange", error);
    showTraceStatus("Could not save open mode preference.", "error");
  }
}

function updateAiSettingsVisibility() {
  const provider = normalizeAiProvider(settAiProvider?.value);
  const isNano = provider === "gemini-nano";
  const isCursor = provider === "cursor-ai";
  const isClaude = provider === "claude-ai";
  const isOpenAi = provider === "openai-codex";
  const isGeminiApi = provider === "gemini-api";
  const isSalesforceManaged =
    provider === "salesforce-einstein-llm" ||
    provider === "salesforce-models-api" ||
    provider === "agentforce-agent";

  if (settAiModelField) settAiModelField.hidden = isNano;
  if (settAiApiKeyField) settAiApiKeyField.hidden = isNano;
  if (settAiEndpointField) settAiEndpointField.hidden = isNano || isGeminiApi;
  if (settAiAgentforceOrgField) settAiAgentforceOrgField.hidden = !isSalesforceManaged;

  if (settAiEndpoint) {
    if (isOpenAi) {
      settAiEndpoint.placeholder = "https://api.openai.com/v1/chat/completions";
    } else if (isClaude) {
      settAiEndpoint.placeholder = "https://api.anthropic.com/v1/messages";
    } else if (isCursor) {
      settAiEndpoint.placeholder = "https://your-cursor-proxy.example.com/v1/chat/completions";
    } else if (isSalesforceManaged) {
      settAiEndpoint.placeholder =
        "https://your-org.my.salesforce.com/services/data/v61.0/einstein/ai/chat/completions";
    } else {
      settAiEndpoint.placeholder = "https://api.example.com/v1/chat/completions";
    }
  }

  if (settAiModel) {
    if (isOpenAi) {
      settAiModel.placeholder = "gpt-4.1-mini";
    } else if (isClaude) {
      settAiModel.placeholder = "claude-3-5-sonnet-latest";
    } else if (isCursor) {
      settAiModel.placeholder = "cursor-default or your deployed model";
    } else if (isSalesforceManaged) {
      settAiModel.placeholder = "Model/deployment or agent name";
    } else if (isGeminiApi) {
      settAiModel.placeholder = "gemini-2.0-flash-lite";
    } else {
      settAiModel.placeholder = "Model or deployment";
    }
  }

  if (!settAiProviderNote) return;
  if (isNano) {
    settAiProviderNote.textContent =
      "Uses Chrome Prompt API (`LanguageModel`) on-device. If unavailable, Chrome version/hardware requirements may not be met.";
    return;
  }
  if (isOpenAi) {
    settAiProviderNote.textContent =
      "Uses OpenAI Chat Completions API with your API key.";
    return;
  }
  if (isClaude) {
    settAiProviderNote.textContent =
      "Uses Anthropic Messages API with your Claude API key.";
    return;
  }
  if (isCursor) {
    settAiProviderNote.textContent =
      "Cursor AI mode expects your token + endpoint (for proxy/gateway setups).";
    return;
  }
  if (isSalesforceManaged) {
    settAiProviderNote.textContent =
      "Org-managed Salesforce mode. Configure org URL and/or endpoint plus a valid org token.";
    return;
  }
  if (isGeminiApi) {
    settAiProviderNote.textContent =
      "Legacy Gemini API mode: provide model and Google API key.";
    return;
  }
  settAiProviderNote.textContent =
    "Configure provider credentials and endpoint to run AI analysis.";
}

async function getConfiguredDebugLevels() {
  try {
    const cfg = await chrome.storage.sync.get({ debugLevels: DEFAULT_DEBUG_LEVELS });
    return { ...DEFAULT_DEBUG_LEVELS, ...(cfg.debugLevels || {}) };
  } catch (error) {
    logJsError("load debug levels from settings", error);
    return { ...DEFAULT_DEBUG_LEVELS };
  }
}

async function getConfiguredTraceDurationMinutes() {
  try {
    const cfg = await chrome.storage.sync.get({
      traceDurationMinutes: SETTINGS_STORAGE_DEFAULTS.traceDurationMinutes,
    });
    return clampTraceMinutes(cfg.traceDurationMinutes);
  } catch (error) {
    logJsError("load trace duration from settings", error);
    return SETTINGS_STORAGE_DEFAULTS.traceDurationMinutes;
  }
}

function isSfUrl(url) {
  if (!url) return false;
  try {
    const h = new URL(url).hostname.toLowerCase();
    return (
      h.includes("salesforce.com") ||
      h.includes("force.com") ||
      h.includes("salesforce-setup.com")
    );
  } catch {
    return false;
  }
}

async function getSfTabId() {
  const cur = await chrome.tabs.query({ active: true, currentWindow: true });
  if (cur[0]?.url && isSfUrl(cur[0].url)) return cur[0].id;
  const w = await chrome.tabs.query({ currentWindow: true });
  const t = w.find((x) => x.url && isSfUrl(x.url));
  if (t) return t.id;
  const all = await chrome.tabs.query({});
  const any = all.find((x) => x.url && isSfUrl(x.url));
  return any?.id ?? null;
}

function getSelectedUserId() {
  return selectedUserId === FILTER_ALL ? null : selectedUserId;
}

function formatTime(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

function clearList() {
  logList.innerHTML = "";
}

function syncSelectAllCheckbox() {
  if (!chkSelectAllLogs) return;
  const boxes = [...logList.querySelectorAll(".log-item__cb")];
  if (boxes.length === 0) {
    chkSelectAllLogs.checked = false;
    chkSelectAllLogs.indeterminate = false;
    return;
  }
  const checked = boxes.filter((b) => b.checked).length;
  chkSelectAllLogs.checked = checked === boxes.length;
  chkSelectAllLogs.indeterminate = checked > 0 && checked < boxes.length;
}

function getSelectedLogIdsFromList() {
  return [...logList.querySelectorAll(".log-item__cb:checked")]
    .map((cb) => cb.closest(".log-item")?.dataset.logId)
    .filter(Boolean);
}

function showTraceStatus(text, tone) {
  traceStatus.hidden = false;
  traceStatus.className = "hint hint--status";
  if (tone === "ok") traceStatus.classList.add("hint--ok");
  if (tone === "warn") traceStatus.classList.add("hint--warn");
  if (tone === "error") traceStatus.classList.add("hint--error");
  traceStatus.textContent = text;
}

function hideTraceStatus() {
  traceStatus.hidden = true;
  traceStatus.className = "hint hint--status";
  traceStatus.textContent = "";
}

function showError(msg) {
  errorState.textContent = msg;
  errorState.hidden = false;
  emptyState.hidden = true;
}

function hideError() {
  errorState.hidden = true;
}

function setBadge(text, ok) {
  if (!statusBadge) return;
  statusBadge.className = "header__count";
  if (!text) {
    statusBadge.hidden = true;
    statusBadge.textContent = "";
    return;
  }
  statusBadge.hidden = false;
  statusBadge.textContent = text;
  if (text === "Error") {
    statusBadge.classList.add("header__count--error");
  } else if (text === "Loading…") {
    statusBadge.classList.add("header__count--loading");
  } else if (ok) {
    statusBadge.classList.add("header__count--ok");
  } else {
    statusBadge.classList.add("header__count--muted");
  }
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function openDetail(logId) {
  const tab = lastSfTabId != null ? `&tabId=${lastSfTabId}` : "";
  const url = chrome.runtime.getURL(
    `details/details.html?logId=${encodeURIComponent(logId)}${tab}`
  );
  chrome.tabs.create({ url });
}

function renderRecords(records) {
  setBadge(`${records.length} logs`, true);
  emptyState.textContent = getSelectedUserId()
    ? "No logs found for selected user."
    : "No logs loaded yet.";
  emptyState.hidden = records.length > 0;
  clearList();

  for (const r of records) {
    const li = document.createElement("li");
    li.className = "log-item";
    li.dataset.logId = r.id;

    const statusClass =
      (r.status || "").toLowerCase() === "success"
        ? "log-item__status--success"
        : "log-item__status--fail";

    li.innerHTML = `
      <label class="log-item__select">
        <input type="checkbox" class="log-item__cb" aria-label="Select log for delete" />
      </label>
      <div class="log-item__body">
        <div class="log-item__top">
          <span class="log-item__time">${escapeHtml(formatTime(r.startTime))}</span>
          <span class="log-item__status ${statusClass}">${escapeHtml(r.status || "—")}</span>
        </div>
        <div class="log-item__meta">
          <div class="log-item__meta-row"><span class="log-item__meta-key">Operation</span><span class="log-item__meta-val">${escapeHtml(r.operation || "—")}</span></div>
          <div class="log-item__meta-row"><span class="log-item__meta-key">Application</span><span class="log-item__meta-val">${escapeHtml(r.application || "—")}</span></div>
          <div class="log-item__meta-row"><span class="log-item__meta-key">User</span><span class="log-item__meta-val">${escapeHtml(r.logUserName || r.logUserId || "—")}</span></div>
          <div class="log-item__meta-row"><span class="log-item__meta-key">Duration</span><span class="log-item__meta-val">${escapeHtml(
            r.durationMs != null ? `${r.durationMs} ms` : "—"
          )}</span></div>
          <div class="log-item__meta-row"><span class="log-item__meta-key">Size</span><span class="log-item__meta-val">${escapeHtml(
      r.logLength != null ? String(r.logLength) : "—"
    )}</span></div>
        </div>
      </div>
    `;

    li.addEventListener("click", (e) => {
      if (e.target.closest(".log-item__select")) return;
      openDetail(r.id);
    });
    const rowCb = li.querySelector(".log-item__cb");
    if (rowCb) {
      rowCb.addEventListener("change", () => syncSelectAllCheckbox());
    }
    logList.appendChild(li);
  }
  syncSelectAllCheckbox();
}

function formatUserLabel(user) {
  return user.name || user.username || user.id;
}

function mergeUsersById(baseUsers, extraUsers) {
  const merged = new Map();
  for (const user of [...(baseUsers || []), ...(extraUsers || [])]) {
    if (!user?.id) continue;
    merged.set(user.id, {
      id: user.id,
      name: user.name || user.username || user.id,
      username: user.username || "",
      userType: user.userType || "",
      isAutomatedProcess: Boolean(user.isAutomatedProcess),
    });
  }
  return [...merged.values()].sort((a, b) => {
    if (a.isAutomatedProcess && !b.isAutomatedProcess) return -1;
    if (!a.isAutomatedProcess && b.isAutomatedProcess) return 1;
    return formatUserLabel(a).localeCompare(formatUserLabel(b), undefined, { sensitivity: "base" });
  });
}

function userMatchesSearch(user, query) {
  if (!query) return true;
  const q = query.toLowerCase();
  return (
    String(user.name || "")
      .toLowerCase()
      .includes(q) ||
    String(user.username || "")
      .toLowerCase()
      .includes(q) ||
    String(user.id || "")
      .toLowerCase()
      .includes(q)
  );
}

function hideTypeahead() {
  userTypeaheadList.hidden = true;
}

function showTypeahead() {
  userTypeaheadList.hidden = false;
}

function setUserSelection(id, label) {
  selectedUserId = id || FILTER_ALL;
  selectedUserLabel = label || "All";
  userSearchInput.value = selectedUserLabel === "All" ? "" : selectedUserLabel;
  btnSetLog.disabled = selectedUserId === FILTER_ALL;
  btnSetLog.title = SET_LOG_TITLE_DEFAULT;
  if (selectedUserId === FILTER_ALL) {
    btnRemoveLog.disabled = true;
    btnRemoveLog.title = REMOVE_LOG_TITLE_NEED_USER;
  }
}

async function clearPersistedDefaultTraceUser() {
  try {
    await chrome.storage.local.remove(DEFAULT_TRACE_USER_KEY);
  } catch (error) {
    logJsError("clearPersistedDefaultTraceUser", error);
  }
}

async function persistDefaultTraceUser(userId, userLabel, expirationDate) {
  const expiresAtMs = Date.parse(expirationDate || "");
  if (!userId || !Number.isFinite(expiresAtMs) || expiresAtMs <= Date.now()) {
    await clearPersistedDefaultTraceUser();
    return;
  }
  try {
    await chrome.storage.local.set({
      [DEFAULT_TRACE_USER_KEY]: {
        userId: String(userId),
        userLabel: String(userLabel || userId),
        expiresAt: new Date(expiresAtMs).toISOString(),
      },
    });
  } catch (error) {
    logJsError("persistDefaultTraceUser", error);
  }
}

async function clearPersistedDefaultTraceUserIfMatches(userId) {
  if (!userId) return;
  try {
    const stored = await chrome.storage.local.get({ [DEFAULT_TRACE_USER_KEY]: null });
    if (stored?.[DEFAULT_TRACE_USER_KEY]?.userId === userId) {
      await chrome.storage.local.remove(DEFAULT_TRACE_USER_KEY);
    }
  } catch (error) {
    logJsError("clearPersistedDefaultTraceUserIfMatches", error);
  }
}

async function restoreDefaultTraceUserSelection() {
  try {
    const stored = await chrome.storage.local.get({ [DEFAULT_TRACE_USER_KEY]: null });
    const pref = stored?.[DEFAULT_TRACE_USER_KEY];
    if (!pref?.userId || !pref?.expiresAt) return false;
    const expiresAtMs = Date.parse(pref.expiresAt);
    if (!Number.isFinite(expiresAtMs) || expiresAtMs <= Date.now()) {
      await chrome.storage.local.remove(DEFAULT_TRACE_USER_KEY);
      return false;
    }
    setUserSelection(pref.userId, pref.userLabel || pref.userId);
    return true;
  } catch (error) {
    logJsError("restoreDefaultTraceUserSelection", error);
    return false;
  }
}

async function applyUserSelectionAndRefresh(id, label) {
  setUserSelection(id, label);
  hideTypeahead();
  await loadLogs();
  await refreshTraceStatusForSelection();
}

function renderUserOptions() {
  const previous = selectedUserId || FILTER_ALL;
  const query = String(userSearchInput.value || "").trim();
  const visibleUsers = allUsers.filter((u) => userMatchesSearch(u, query)).slice(0, 50);
  userTypeaheadList.innerHTML = "";

  const allItem = document.createElement("div");
  allItem.className = `typeahead-item${previous === FILTER_ALL ? " typeahead-item--active" : ""}`;
  allItem.textContent = "All";
  allItem.addEventListener("mousedown", async (e) => {
    e.preventDefault();
    await applyUserSelectionAndRefresh(FILTER_ALL, "All");
  });
  userTypeaheadList.appendChild(allItem);

  for (const user of visibleUsers) {
    const item = document.createElement("div");
    const isActive = user.id === previous;
    item.className = `typeahead-item${isActive ? " typeahead-item--active" : ""}`;
    item.innerHTML = `${escapeHtml(formatUserLabel(user))}${
      user.username ? `<span class="typeahead-item__sub">${escapeHtml(user.username)}</span>` : ""
    }`;
    item.addEventListener("mousedown", async (e) => {
      e.preventDefault();
      await applyUserSelectionAndRefresh(user.id, formatUserLabel(user));
    });
    userTypeaheadList.appendChild(item);
  }

  if (visibleUsers.length === 0) {
    const emptyItem = document.createElement("div");
    emptyItem.className = "typeahead-item";
    emptyItem.textContent =
      query.length >= MIN_REMOTE_USER_SEARCH_LENGTH
        ? "No users found."
        : `Type at least ${MIN_REMOTE_USER_SEARCH_LENGTH} characters to search all users.`;
    userTypeaheadList.appendChild(emptyItem);
  }

  if (!query && selectedUserId === FILTER_ALL) {
    userSearchInput.placeholder = "All";
  }
}

async function loadActiveUsers() {
  try {
    const tabId = await getSfTabId();
    if (tabId == null) return;
    lastSfTabId = tabId;
    const res = await chrome.runtime.sendMessage({ type: "LIST_ACTIVE_USERS", tabId });
    if (!res?.ok) {
      showTraceStatus(res?.error || "Could not load active users.", "error");
      return;
    }
    allUsers = mergeUsersById(allUsers, res.users || []);
    setUserSelection(selectedUserId, selectedUserLabel);
    renderUserOptions();
  } catch (error) {
    logJsError("loadActiveUsers", error);
    showTraceStatus("Could not load users. Check console logs.", "error");
  }
}

async function searchUsersByQuery(rawQuery) {
  const query = String(rawQuery || "").trim();
  if (query.length < MIN_REMOTE_USER_SEARCH_LENGTH) return;
  const requestSeq = ++userSearchRequestSeq;
  try {
    const tabId = await getSfTabId();
    if (tabId == null) return;
    lastSfTabId = tabId;
    const res = await chrome.runtime.sendMessage({
      type: "SEARCH_USERS",
      tabId,
      query,
      limit: 100,
    });
    if (requestSeq !== userSearchRequestSeq) return;
    if (!res?.ok) {
      showTraceStatus(res?.error || "Could not search users.", "error");
      return;
    }
    allUsers = mergeUsersById(allUsers, res.users || []);
    renderUserOptions();
  } catch (error) {
    logJsError("searchUsersByQuery", error);
    if (requestSeq === userSearchRequestSeq) {
      showTraceStatus("Could not search users. Check console logs.", "error");
    }
  }
}

async function deleteLogsMessage(payload) {
  const tabId = await getSfTabId();
  if (tabId == null) {
    showTraceStatus("Open a Salesforce tab first.", "error");
    return null;
  }
  lastSfTabId = tabId;
  return chrome.runtime.sendMessage({
    type: "DELETE_LOGS",
    tabId,
    ...payload,
  });
}

function summarizeDeleteResponse(res) {
  if (!res) {
    showTraceStatus("No response from extension.", "error");
    return;
  }
  if (res.ok === false && res.error) {
    showTraceStatus(res.error, "error");
    return;
  }
  if (res.totalAttempted === 0 && res.message) {
    showTraceStatus(res.message, "warn");
    return;
  }
  if (res.ok) {
    showTraceStatus(`Deleted ${res.deleted} log(s).`, "ok");
    return;
  }
  if (res.partial) {
    showTraceStatus(
      `Deleted ${res.deleted} of ${res.totalAttempted}. ${res.failed} failed (permissions or locks).`,
      "warn"
    );
    return;
  }
  const firstErr = res.errors?.[0]?.message || "Delete failed.";
  showTraceStatus(firstErr, "error");
}

async function loadLogs() {
  try {
    hideError();
    const tabId = await getSfTabId();
    lastSfTabId = tabId;
    if (tabId == null) {
      showError(
        "No Salesforce tab found. Open Lightning, Setup, or your org in another tab."
      );
      clearList();
      setBadge("", false);
      return;
    }

    setBadge("Loading…", false);
    const logUserId = getSelectedUserId();
    const res = await chrome.runtime.sendMessage({ type: "LIST_LOGS", tabId, logUserId });

    if (!res?.ok) {
      showError(res?.error || "Failed to load logs.");
      clearList();
      setBadge("Error", false);
      return;
    }

    hideError();
    renderRecords(res.records || []);
  } catch (error) {
    logJsError("loadLogs", error);
    showError("Failed to load logs. Check console logs.");
    clearList();
    setBadge("Error", false);
  }
}

async function refreshTraceStatusForSelection() {
  try {
    const userId = getSelectedUserId();
    btnSetLog.title = SET_LOG_TITLE_DEFAULT;
    btnRemoveLog.title = REMOVE_LOG_TITLE_NO_TRACE;
    if (!userId) {
      btnSetLog.disabled = true;
      btnRemoveLog.disabled = true;
      btnRemoveLog.title = REMOVE_LOG_TITLE_NEED_USER;
      hideTraceStatus();
      return;
    }
    const tabId = await getSfTabId();
    if (tabId == null) {
      btnRemoveLog.disabled = true;
      btnRemoveLog.title = REMOVE_LOG_TITLE_NEED_SF_TAB;
      return;
    }
    lastSfTabId = tabId;
    const res = await chrome.runtime.sendMessage({
      type: "GET_TRACE_FLAG_STATUS",
      tabId,
      userId,
    });
    if (!res?.ok) {
      showTraceStatus(res?.error || "Could not read trace status.", "error");
      btnSetLog.disabled = false;
      btnRemoveLog.disabled = true;
      btnRemoveLog.title = REMOVE_LOG_TITLE_NO_TRACE;
      return;
    }
    if (res.active && res.expirationDate) {
      await persistDefaultTraceUser(userId, selectedUserLabel, res.expirationDate);
      showTraceStatus(`Trace already active until ${formatTime(res.expirationDate)}.`, "ok");
      btnSetLog.disabled = true;
      btnSetLog.title = SET_LOG_TITLE_ACTIVE;
      btnRemoveLog.disabled = false;
      btnRemoveLog.title = REMOVE_LOG_TITLE_REMOVE;
      return;
    }
    if (res.expiredAt) {
      await clearPersistedDefaultTraceUserIfMatches(userId);
      showTraceStatus(
        `Trace expired at ${formatTime(res.expiredAt)}. Click Set Log to enable again.`,
        "warn"
      );
      btnSetLog.disabled = false;
      btnRemoveLog.disabled = true;
      btnRemoveLog.title = REMOVE_LOG_TITLE_NO_TRACE;
      return;
    }
    await clearPersistedDefaultTraceUserIfMatches(userId);
    showTraceStatus("No active trace for this user. Click Set Log.", "warn");
    btnSetLog.disabled = false;
    btnRemoveLog.disabled = true;
    btnRemoveLog.title = REMOVE_LOG_TITLE_NO_TRACE;
  } catch (error) {
    logJsError("refreshTraceStatusForSelection", error);
    showTraceStatus("Could not read trace status. Check console logs.", "error");
    const userId = getSelectedUserId();
    if (userId) btnSetLog.disabled = false;
    btnRemoveLog.disabled = true;
    btnRemoveLog.title = REMOVE_LOG_TITLE_NO_TRACE;
  }
}

async function setTraceForSelectedUser() {
  const userId = getSelectedUserId();
  if (!userId) {
    showTraceStatus("Select a user first, then click Set Log.", "warn");
    return;
  }
  const tabId = await getSfTabId();
  if (tabId == null) {
    showTraceStatus("Open a Salesforce tab first.", "error");
    return;
  }
  lastSfTabId = tabId;

  btnSetLog.disabled = true;
  btnRemoveLog.disabled = true;
  const oldText = btnSetLog.textContent || "Set Log";
  btnSetLog.textContent = "Setting...";
  try {
    const res = await chrome.runtime.sendMessage({
      type: "SET_TRACE_FLAG",
      tabId,
      userId,
      durationMinutes: await getConfiguredTraceDurationMinutes(),
      debugLevels: await getConfiguredDebugLevels(),
    });

    if (!res?.ok) {
      showTraceStatus(res?.error || "Failed to set trace flag for selected user.", "error");
      return;
    }

    if (res.alreadyActive) {
      showTraceStatus(
        `Trace already exists and is active until ${formatTime(res.expirationDate)}.`,
        "ok"
      );
    } else {
      showTraceStatus(
        `Trace enabled until ${formatTime(res.expirationDate)} for selected user.`,
        "ok"
      );
    }
    await persistDefaultTraceUser(userId, selectedUserLabel, res.expirationDate);
    await loadLogs();
  } catch (error) {
    logJsError("setTraceForSelectedUser", error);
    showTraceStatus("Failed to set trace flag for selected user. Check console logs.", "error");
  } finally {
    btnSetLog.textContent = oldText;
  }
}

async function removeTraceForSelectedUser() {
  const userId = getSelectedUserId();
  if (!userId) {
    showTraceStatus("Select a user first, then remove trace.", "warn");
    return;
  }
  if (
    !confirm(
      "Remove the debug trace for this user? New logs will not be captured until you set the trace again."
    )
  ) {
    return;
  }
  const tabId = await getSfTabId();
  if (tabId == null) {
    showTraceStatus("Open a Salesforce tab first.", "error");
    return;
  }
  lastSfTabId = tabId;

  const oldText = btnRemoveLog.textContent || "Remove log";
  btnRemoveLog.disabled = true;
  btnSetLog.disabled = true;
  btnRemoveLog.textContent = "Removing…";
  try {
    const res = await chrome.runtime.sendMessage({
      type: "REMOVE_TRACE_FLAG",
      tabId,
      userId,
    });
    if (!res?.ok) {
      showTraceStatus(res?.error || "Could not remove trace.", "error");
      return;
    }
    if (res.removed === false) {
      showTraceStatus(res.message || "No active trace to remove.", "warn");
      return;
    }
    showTraceStatus("Debug trace removed for this user.", "ok");
    await clearPersistedDefaultTraceUserIfMatches(userId);
    await loadLogs();
  } catch (error) {
    logJsError("removeTraceForSelectedUser", error);
    showTraceStatus("Remove trace failed. Check console.", "error");
  } finally {
    btnRemoveLog.textContent = oldText;
    await refreshTraceStatusForSelection();
  }
}

function scheduleRefresh() {
  if (refreshTimer) {
    clearInterval(refreshTimer);
    refreshTimer = null;
  }
  const sec = Number(refreshSelect.value);
  if (!sec) return;
  refreshTimer = setInterval(() => {
    loadLogs();
  }, sec * 1000);
}

btnRefresh.addEventListener("click", async () => {
  await loadLogs();
  await refreshTraceStatusForSelection();
});

btnSetLog.addEventListener("click", async () => {
  await setTraceForSelectedUser();
  await refreshTraceStatusForSelection();
});

btnRemoveLog.addEventListener("click", async () => {
  await removeTraceForSelectedUser();
});

if (openModeToggle) {
  openModeToggle.addEventListener("change", async () => {
    await handleOpenModeToggleChange(openModeToggle.checked);
  });
}

if (settOpenModeTab) {
  settOpenModeTab.addEventListener("change", async () => {
    await handleOpenModeToggleChange(settOpenModeTab.checked);
    saveSettingsOverlay();
  });
}

refreshSelect.addEventListener("change", () => {
  chrome.storage.sync.set({ refreshSeconds: Number(refreshSelect.value) });
  scheduleRefresh();
});

if (chkSelectAllLogs) {
  chkSelectAllLogs.addEventListener("change", () => {
    const on = chkSelectAllLogs.checked;
    logList.querySelectorAll(".log-item__cb").forEach((c) => {
      c.checked = on;
    });
    chkSelectAllLogs.indeterminate = false;
  });
}

btnClearSelected.addEventListener("click", async () => {
  const ids = getSelectedLogIdsFromList();
  if (ids.length === 0) {
    showTraceStatus("Select one or more logs (checkbox), then delete.", "warn");
    return;
  }
  if (
    !confirm(
      `Delete ${ids.length} debug log(s) from Salesforce? This cannot be undone.`
    )
  ) {
    return;
  }
  btnClearSelected.disabled = true;
  try {
    const res = await deleteLogsMessage({ deleteAll: false, logIds: ids });
    summarizeDeleteResponse(res);
    await loadLogs();
    await refreshTraceStatusForSelection();
  } catch (error) {
    logJsError("btnClearSelected", error);
    showTraceStatus("Delete failed. Check console.", "error");
  } finally {
    btnClearSelected.disabled = false;
  }
});

btnClearAllLogs.addEventListener("click", async () => {
  const isAllUsers = selectedUserId === FILTER_ALL;
  const scope = isAllUsers
    ? "ALL users in this org (every Apex debug log you are allowed to query)"
    : `user “${selectedUserLabel}” only`;
  if (
    !confirm(
      `Delete debug logs for ${scope}?\n\nThis removes them from Salesforce and cannot be undone.`
    )
  ) {
    return;
  }
  btnClearAllLogs.disabled = true;
  try {
    const res = await deleteLogsMessage({
      deleteAll: true,
      logUserId: isAllUsers ? null : selectedUserId,
    });
    summarizeDeleteResponse(res);
    await loadLogs();
    await refreshTraceStatusForSelection();
  } catch (error) {
    logJsError("btnClearAllLogs", error);
    showTraceStatus("Delete all failed. Check console.", "error");
  } finally {
    btnClearAllLogs.disabled = false;
  }
});

userSearchInput.addEventListener("input", () => {
  selectedUserId = FILTER_ALL;
  selectedUserLabel = "All";
  btnSetLog.disabled = true;
  btnSetLog.title = SET_LOG_TITLE_DEFAULT;
  btnRemoveLog.disabled = true;
  btnRemoveLog.title = REMOVE_LOG_TITLE_NEED_USER;
  renderUserOptions();
  showTypeahead();
  const query = String(userSearchInput.value || "").trim();
  if (userSearchDebounceTimer) clearTimeout(userSearchDebounceTimer);
  if (query.length < MIN_REMOTE_USER_SEARCH_LENGTH) return;
  userSearchDebounceTimer = setTimeout(() => {
    searchUsersByQuery(query);
  }, 220);
});

userSearchInput.addEventListener("focus", () => {
  renderUserOptions();
  showTypeahead();
});

userSearchInput.addEventListener("blur", () => {
  setTimeout(() => {
    hideTypeahead();
  }, 120);
});

function getSettingsDebugFieldPairs() {
  return [
    [settDbgApexCode, "ApexCode"],
    [settDbgApexProfiling, "ApexProfiling"],
    [settDbgCallout, "Callout"],
    [settDbgDatabase, "Database"],
    [settDbgSystem, "System"],
    [settDbgValidation, "Validation"],
    [settDbgVisualforce, "Visualforce"],
    [settDbgWorkflow, "Workflow"],
  ];
}

if (settDbgApexCode) {
  initAllDebugLevelSelects(getSettingsDebugFieldPairs());
}

function loadSettingsOverlayFromStorage() {
  chrome.storage.sync.get(
    { ...SETTINGS_STORAGE_DEFAULTS, debugLevels: DEFAULT_DEBUG_LEVELS },
    (cfg) => {
      if (settLogLimit) settLogLimit.value = String(clampLogLimit(cfg.logLimit));
      const openMode = normalizeOpenMode(cfg.openMode);
      if (settOpenModeTab) settOpenModeTab.checked = openMode === "tab";
      if (openModeToggle) openModeToggle.checked = openMode === "tab";
      if (settRefreshSeconds) {
        const v = String(
          cfg.refreshSeconds ?? SETTINGS_STORAGE_DEFAULTS.refreshSeconds
        );
        const ok = [...settRefreshSeconds.options].some((o) => o.value === v);
        settRefreshSeconds.value = ok
          ? v
          : String(SETTINGS_STORAGE_DEFAULTS.refreshSeconds);
      }
      if (settTraceDurationMinutes) {
        const v = String(
          cfg.traceDurationMinutes ?? SETTINGS_STORAGE_DEFAULTS.traceDurationMinutes
        );
        const ok = [...settTraceDurationMinutes.options].some((o) => o.value === v);
        settTraceDurationMinutes.value = ok ? v : "15";
      }
      if (settAiProvider) {
        settAiProvider.value = normalizeAiProvider(cfg.aiProvider);
      }
      if (settAiModel) {
        settAiModel.value = sanitizeAiText(cfg.aiModel, SETTINGS_STORAGE_DEFAULTS.aiModel);
      }
      if (settAiApiKey) {
        settAiApiKey.value = sanitizeAiText(cfg.aiApiKey);
      }
      if (settAiEndpoint) {
        settAiEndpoint.value = sanitizeAiText(cfg.aiEndpoint);
      }
      if (settAiAgentforceOrgUrl) {
        settAiAgentforceOrgUrl.value = sanitizeAiText(cfg.aiAgentforceOrgUrl);
      }
      applyDebugLevelsToSelects(getSettingsDebugFieldPairs(), cfg.debugLevels);
      updateAiSettingsVisibility();
    }
  );
}

function showSettingsSavedHint() {
  if (!settSavedHint) return;
  settSavedHint.textContent = "Saved";
  setTimeout(() => {
    settSavedHint.textContent = "";
  }, 1500);
}

function saveSettingsOverlay() {
  const logLimit = clampLogLimit(settLogLimit?.value);
  const refreshSeconds = Number(settRefreshSeconds?.value);
  const traceDurationMinutes = clampTraceMinutes(settTraceDurationMinutes?.value);
  const debugLevels = readDebugLevelsFromSelects(getSettingsDebugFieldPairs());
  const openMode = settOpenModeTab?.checked ? "tab" : "popup";
  const aiProvider = normalizeAiProvider(settAiProvider?.value);
  const aiModel = sanitizeAiText(settAiModel?.value, SETTINGS_STORAGE_DEFAULTS.aiModel);
  const aiApiKey = sanitizeAiText(settAiApiKey?.value);
  const aiEndpoint = sanitizeAiText(settAiEndpoint?.value);
  const aiAgentforceOrgUrl = sanitizeAiText(settAiAgentforceOrgUrl?.value);
  chrome.storage.sync.set(
    {
      logLimit,
      openMode,
      refreshSeconds: Number.isFinite(refreshSeconds)
        ? refreshSeconds
        : SETTINGS_STORAGE_DEFAULTS.refreshSeconds,
      traceDurationMinutes,
      debugLevels,
      aiProvider,
      aiModel,
      aiApiKey,
      aiEndpoint,
      aiAgentforceOrgUrl,
    },
    () => {
      showSettingsSavedHint();
      if (openModeToggle) {
        openModeToggle.checked = openMode === "tab";
      }
      if (refreshSelect && settRefreshSeconds) {
        const v = settRefreshSeconds.value;
        const opt = [...refreshSelect.options].find((o) => o.value === v);
        if (opt) refreshSelect.value = opt.value;
      }
      scheduleRefresh();
    }
  );
}

function openSettingsOverlay() {
  if (!settingsOverlay) return;
  loadSettingsOverlayFromStorage();
  settingsOverlay.hidden = false;
  setTimeout(() => btnCloseSettings?.focus(), 0);
}

function closeSettingsOverlay() {
  if (!settingsOverlay) return;
  settingsOverlay.hidden = true;
  if (settSavedHint) settSavedHint.textContent = "";
}

if (btnOpenSettings) {
  btnOpenSettings.addEventListener("click", () => openSettingsOverlay());
}
if (btnCloseSettings) {
  btnCloseSettings.addEventListener("click", () => closeSettingsOverlay());
}
if (settingsOverlay) {
  settingsOverlay.addEventListener("click", (e) => {
    if (e.target === settingsOverlay) closeSettingsOverlay();
  });
}
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (!settingsOverlay || settingsOverlay.hidden) return;
  closeSettingsOverlay();
});

if (settAiProvider) {
  settAiProvider.addEventListener("change", () => {
    updateAiSettingsVisibility();
    saveSettingsOverlay();
  });
}

for (const el of [
  settLogLimit,
  settRefreshSeconds,
  settTraceDurationMinutes,
  settDbgApexCode,
  settDbgApexProfiling,
  settDbgCallout,
  settDbgDatabase,
  settDbgSystem,
  settDbgValidation,
  settDbgVisualforce,
  settDbgWorkflow,
  settAiModel,
  settAiApiKey,
  settAiEndpoint,
  settAiAgentforceOrgUrl,
]) {
  el?.addEventListener("change", saveSettingsOverlay);
}

async function initPopup() {
  const shouldContinue = await maybeOpenFullTabFromPreference();
  if (!shouldContinue) return;
  const cfg = await chrome.storage.sync.get(SETTINGS_STORAGE_DEFAULTS);
  const openMode = normalizeOpenMode(cfg.openMode);
  if (openModeToggle) openModeToggle.checked = openMode === "tab";
  if (settOpenModeTab) settOpenModeTab.checked = openMode === "tab";
  updateAiSettingsVisibility();

  btnSetLog.disabled = true;
  btnRemoveLog.disabled = true;
  btnRemoveLog.title = REMOVE_LOG_TITLE_NEED_USER;
  const v = String(cfg.refreshSeconds ?? SETTINGS_STORAGE_DEFAULTS.refreshSeconds);
  const opt = [...refreshSelect.options].find((o) => o.value === v);
  refreshSelect.value = opt ? opt.value : String(SETTINGS_STORAGE_DEFAULTS.refreshSeconds);
  await restoreDefaultTraceUserSelection();
  await loadActiveUsers();
  await loadLogs();
  await refreshTraceStatusForSelection();
  scheduleRefresh();
}

initPopup().catch((error) => {
  logJsError("initPopup", error);
  showError("Failed to initialize popup. Check console logs.");
});
